## ----, echo = FALSE, message = FALSE-------------------------------------
knitr::opts_chunk$set(
  comment = "#>",
  error = FALSE,
  tidy = FALSE
)

## ------------------------------------------------------------------------
cat(readLines(file.path(R.home("doc"), "KEYWORDS")), sep = "\n")

