This app uses a `textarea` input to store R code, which is reformatted by
`formatR::tidy_source()`. The result is written back in the text box. Click the
`demo` button to load a demo, or paste your own R code here to see what this app
can do.
