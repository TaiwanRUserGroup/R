# DataTaipei
R Client for http://data.taipei/

## 安裝

```r
library(devtools)
install_github('TaipeiRHackers/DataTaipei')
```

## 範例

[DataTaipei應用範例 - 台北市youbike站點資料](http://taipeirhackers.github.io/DataTaipei/youbike.html)

[DataTaipei應用範例 - 台北市天氣資料](http://taipeirhackers.github.io/DataTaipei/weather.html)

[DataTaipei應用範例 - 台北市不動產資料](http://taipeirhackers.github.io/DataTaipei/estate.html)
