datalist <- function() {
  dataTaipei_GET("datalist")
}