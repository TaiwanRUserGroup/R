/*
 *  /MathJax/jax/output/HTML-CSS/fonts/TeX/Main/Regular/GeometricShapes.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS.MathJax_Main,{9651:[716,0,889,59,828],9657:[505,5,500,26,474],9661:[500,215,889,59,828],9667:[505,5,500,26,473],9711:[715,215,1000,56,944]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/Main/Regular/GeometricShapes.js");

